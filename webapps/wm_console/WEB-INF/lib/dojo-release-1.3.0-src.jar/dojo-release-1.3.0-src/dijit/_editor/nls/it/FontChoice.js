({
	fontSize: "Dimensione",
	fontName: "Carattere",
	formatBlock: "Formato",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",

	p: "Paragrafo",
	h1: "Intestazione",
	h2: "Sottointestazione",
	h3: "Sottointestazione secondaria",
	pre: "Preformattato",

	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large"
})