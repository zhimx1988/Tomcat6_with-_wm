({
	buttonOk: "OK",
	buttonCancel: "Ακύρωση",
	buttonSave: "Αποθήκευση",
	itemClose: "Κλείσιμο"
})
