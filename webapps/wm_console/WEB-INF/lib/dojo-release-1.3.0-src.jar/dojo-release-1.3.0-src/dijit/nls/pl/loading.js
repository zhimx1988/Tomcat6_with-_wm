({
	loadingState: "Trwa ładowanie...",
	errorState: "Niestety, wystąpił błąd"
})
