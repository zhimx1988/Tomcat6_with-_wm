({
	loadingState: "Wird geladen...",
	errorState: "Es ist ein Fehler aufgetreten."
})
